package com.example.recipeFinder.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.example.recipeFinder.MyApplication;
import com.example.recipeFinder.R;
import com.example.recipeFinder.activities.adminActivities.DashboardAdminActivity;
import com.example.recipeFinder.activities.userActivities.DashboardUserActivity;
import com.example.recipeFinder.activities.userActivities.ProfileEditActivity;
import com.example.recipeFinder.adapters.AdapterRecipeFavorite;
import com.example.recipeFinder.databinding.ActivityProfileBinding;
import com.example.recipeFinder.models.ModelRecipe;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {

    private ActivityProfileBinding binding;

    private FirebaseAuth firebaseAuth;

    private ArrayList<ModelRecipe> recipeArrayList;
    private AdapterRecipeFavorite adapterRecipeFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        firebaseAuth = FirebaseAuth.getInstance();
        loadUserInfo();
        loadFavoriteRecipes();

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
                onBackPressed();
            }
        });


        binding.logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                checkUser();
            }
        });

        binding.profileEditIb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, ProfileEditActivity.class));

            }
        });
    }

    private void loadUserInfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String email = "" + snapshot.child("email").getValue();
                        String name = "" + snapshot.child("name").getValue();
                        String profileImage = "" + snapshot.child("profileImage").getValue();
                        String timestamp = "" + snapshot.child("timestamp").getValue();
                        String uid = "" + snapshot.child("uid").getValue();

                        String formattedDate = MyApplication.formatTimestamp(Long.valueOf(timestamp));

                        binding.nameTv.setText(name);
                        binding.emailTv.setText(email);
                        binding.memberDateTv.setText(formattedDate);
                        if (!ProfileActivity.this.isFinishing()) {
                            Glide.with(ProfileActivity.this)
                                    .load(profileImage)
                                    .placeholder(R.drawable.ic_person_darkorange)
                                    .into(binding.profileSiv);
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
    private void checkUser() {

        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser == null) {
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
        else {}
    }

    private void loadFavoriteRecipes() {
        recipeArrayList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child("Favorites")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        recipeArrayList.clear();

                        for (DataSnapshot ds: snapshot.getChildren()) {
                            String recipeId = "" + ds.child("recipeId").getValue();
                            ModelRecipe modelRecipe = new ModelRecipe();
                            modelRecipe.setId(recipeId);

                            recipeArrayList.add(modelRecipe);
                        }

                        binding.favoriteRecipesCountTv.setText("" + recipeArrayList.size());

                        adapterRecipeFavorite = new AdapterRecipeFavorite(ProfileActivity.this,
                                recipeArrayList);
                        binding.recipesRv.setAdapter(adapterRecipeFavorite);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}