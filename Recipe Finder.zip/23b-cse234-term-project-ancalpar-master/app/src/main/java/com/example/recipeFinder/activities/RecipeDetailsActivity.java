package com.example.recipeFinder.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.example.recipeFinder.MyApplication;
import com.example.recipeFinder.R;
import com.example.recipeFinder.adapters.AdapterComment;
import com.example.recipeFinder.databinding.ActivityRecipeDetailsBinding;
import com.example.recipeFinder.databinding.DialogCommentAddBinding;
import com.example.recipeFinder.models.ModelComment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class RecipeDetailsActivity extends AppCompatActivity {

    private ActivityRecipeDetailsBinding binding;

    String recipeId;
    boolean isInMyFavorites = false;

    private FirebaseAuth firebaseAuth;

    private ProgressDialog progressDialog;

    private ArrayList<ModelComment> commentArrayList;
    private AdapterComment adapterComment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRecipeDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        recipeId = intent.getStringExtra("recipeId");

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait.");
        progressDialog.setCanceledOnTouchOutside(false);

        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null) {
            checkIsFavorite();
        }

        loadRecipeDetails();
        loadComments();
        MyApplication.incrementRecipeViewCount(recipeId);


        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        binding.favoriteIb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (firebaseAuth.getCurrentUser() == null) {
                    Toast.makeText(RecipeDetailsActivity.this, "Please login.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (isInMyFavorites) {
                        MyApplication.removeFromFavorite(RecipeDetailsActivity.this, recipeId);
                    }
                    else {
                        MyApplication.addToFavorite(RecipeDetailsActivity.this, recipeId);
                    }
                }
            }
        });

        binding.addCommentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (firebaseAuth.getCurrentUser() == null) {
                    Toast.makeText(RecipeDetailsActivity.this, "You're not logged in!",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    addCommentDialog();
                }
            }
        });
    }

    private void loadComments() {
        commentArrayList = new ArrayList<>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.child(recipeId).child("Comments")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        commentArrayList.clear();
                        double ratingSum = 0;
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            ModelComment model = ds.getValue(ModelComment.class);
                            commentArrayList.add(model);
                            ratingSum +=  ds.child("rating").getValue(double.class);
                        }

                        adapterComment = new AdapterComment(RecipeDetailsActivity.this,
                                commentArrayList);
                        binding.commentsRv.setAdapter(adapterComment);

                        double rating = ratingSum / commentArrayList.size();
                        if (ratingSum != 0)
                            binding.ratingTv.setText(String.format(Locale.US, "%.1f", rating));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private String comment = "";
    private float rating = 0;
    private void addCommentDialog() {
        DialogCommentAddBinding commentAddBinding =
                DialogCommentAddBinding.inflate(LayoutInflater.from(this));

        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.CustomDialog);
        builder.setView(commentAddBinding.getRoot());

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        commentAddBinding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        commentAddBinding.submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comment = commentAddBinding.commentEt.getText().toString().trim();
                rating = commentAddBinding.ratingBar.getRating();
                if (TextUtils.isEmpty(comment)) {
                    Toast.makeText(RecipeDetailsActivity.this, "Enter your comment!",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    alertDialog.dismiss();
                    addComment();
                }
            }
        });
    }

    private void addComment() {
        progressDialog.setMessage("Adding comment");
        progressDialog.show();

        String timestamp = "" + System.currentTimeMillis();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("id", "" + timestamp);
        hashMap.put("recipeId", "" + recipeId);
        hashMap.put("timestamp", "" + timestamp);
        hashMap.put("comment", "" + comment);
        hashMap.put("rating", rating);
        hashMap.put("uid", "" + firebaseAuth.getUid());

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.child(recipeId).child("Comments").child(timestamp)
                .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(RecipeDetailsActivity.this,
                                "Comment successfully added.", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(RecipeDetailsActivity.this,
                                "Failed to add comment due to " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });

    }


    private void loadRecipeDetails() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.child(recipeId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String title = "" + snapshot.child("title").getValue();
                        String description = "" + snapshot.child("description").getValue();
                        String categoryId = "" + snapshot.child("categoryId").getValue();
                        String viewsCount = "" + snapshot.child("viewsCount").getValue();


                        binding.titleTv.setText(title);
                        MyApplication.loadCategory(
                                "" + categoryId,
                                binding.categoryTv
                        );
                        binding.viewsTv.setText(viewsCount);
                        binding.descriptionTv.setText(description);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void checkIsFavorite() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child("Favorites").child(recipeId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        isInMyFavorites = snapshot.exists();

                        if (isInMyFavorites) {
                            binding.favoriteIb.setImageResource(R.drawable.ic_favorite_darkorange);
                        }
                        else {
                            binding.favoriteIb.setImageResource(R.drawable.ic_favorite_border_darkorange);
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}