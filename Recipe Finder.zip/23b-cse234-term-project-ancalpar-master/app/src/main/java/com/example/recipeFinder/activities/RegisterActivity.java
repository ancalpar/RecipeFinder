package com.example.recipeFinder.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.example.recipeFinder.activities.userActivities.DashboardUserActivity;
import com.example.recipeFinder.R;
import com.example.recipeFinder.databinding.ActivityRegisterBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    private FirebaseAuth firebaseAuth;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setBackgroundDrawableResource(R.drawable.background_app);

        firebaseAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait.");
        progressDialog.setCanceledOnTouchOutside(false);

        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateData();
            }
        });

        binding.nameEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                int name = binding.nameEt.getText().toString().length();
                if (name > 2 && name < 31)
                    binding.nameEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_person_darkorange,0,0,0);
                else
                    binding.nameEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_person_gray,0,0,0);
            }
        });
        binding.emailEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String email = binding.emailEt.getText().toString();
                if (Patterns.EMAIL_ADDRESS.matcher(email).matches())
                    binding.emailEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_email_darkorange,0,0,0);
                else
                    binding.emailEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_email_gray,0,0,0);
            }
        });
        binding.passwordEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String password = binding.passwordEt.getText().toString();
                if (password.length() > 7 && password.length() < 33)
                    binding.passwordEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_lock_darkorange, 0, 0, 0);
                else
                    binding.passwordEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_lock_gray, 0, 0, 0);
            }
        });
        binding.confirmPasswordEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String password = binding.passwordEt.getText().toString();
                String confirmPassword = binding.confirmPasswordEt.getText().toString();
                if (password.equals(confirmPassword))
                    binding.confirmPasswordEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_lock_darkorange, 0, 0, 0);
                else
                    binding.confirmPasswordEt.setCompoundDrawablesRelativeWithIntrinsicBounds(
                            R.drawable.ic_lock_gray, 0, 0, 0);
            }
        });
    }

    private String name = "", email = "", password = "";
    private void validateData() {
        name = binding.nameEt.getText().toString().trim();
        email = binding.emailEt.getText().toString().trim();
        password = binding.passwordEt.getText().toString().trim();
        String confirmPassword = binding.confirmPasswordEt.getText().toString().trim();

        if (!nameControl(name).isEmpty())
            Toast.makeText(RegisterActivity.this,
                    nameControl(name), Toast.LENGTH_SHORT).show();
        else if (!emailControl(email).isEmpty())
            Toast.makeText(RegisterActivity.this,
                    emailControl(email), Toast.LENGTH_SHORT).show();
        else if (!passwordControl(password,confirmPassword).isEmpty())
            Toast.makeText(RegisterActivity.this,
                    passwordControl(password,confirmPassword), Toast.LENGTH_SHORT).show();
        else
            createUserAccount();
    }

    private String passwordControl(String password, String confirmPassword) {
        if (TextUtils.isEmpty(password))
            return "Please enter a password.";
        else if (password.length() < 8) {
            return "Please enter your password with more than 7 characters.";
        }
        else if (password.length() > 32) {
            return "Please enter your password with less than 33 characters.";
        }
        else if (TextUtils.isEmpty(confirmPassword)) {
            return "Please confirm your password.";
        }
        else if (!password.equals(confirmPassword)) {
            return "Passwords do not match!";
        } return "";
    }

    private String emailControl(String email) {
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return "Invalid email address format!";
        } return "";
    }

    private String nameControl(String name) {
        if (TextUtils.isEmpty(name)) {
            return "Please enter your name.";
        }
        else if (name.length() > 30) {
            return "Please enter your name with less than 31 characters.";
        }
        else if (name.length() < 3) {
            return "Please enter your name with more than 3 characters.";
        } return "";
    }


    private void createUserAccount() {
        progressDialog.setMessage("Creating your account, please wait...");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        updateUserInfo();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this,
                                "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateUserInfo() {
        progressDialog.setMessage("Saving user info...");

        long timestamp = System.currentTimeMillis();

        String uid = firebaseAuth.getUid();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", uid);
        hashMap.put("email", email);
        hashMap.put("name", name);
        hashMap.put("profileImage", "");
        hashMap.put("userType", "user");
        hashMap.put("timestamp", timestamp);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(uid)
                .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this,
                                "Account created.", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(
                                RegisterActivity.this, DashboardUserActivity.class));
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(RegisterActivity.this,
                                "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}