package com.example.recipeFinder.activities.adminActivities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.example.recipeFinder.R;
import com.example.recipeFinder.adapters.AdapterRecipeAdmin;
import com.example.recipeFinder.databinding.ActivityRecipeListAdminBinding;
import com.example.recipeFinder.models.ModelRecipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RecipeListAdminActivity extends AppCompatActivity {

    private ActivityRecipeListAdminBinding binding;

    private ArrayList<ModelRecipe> recipeArrayList;
    private AdapterRecipeAdmin adapterRecipeAdmin;

    String categoryId, categoryTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecipeListAdminBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setBackgroundDrawableResource(R.drawable.background_app);

        Intent intent = getIntent();
        categoryId = intent.getStringExtra("categoryId");
        categoryTitle = intent.getStringExtra("categoryTitle");


        binding.subTitleTv.setText(categoryTitle);

        loadRecipeList();

        binding.searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    adapterRecipeAdmin.getFilter().filter(s);
                }
                catch (Exception e) {

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.addRecipeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecipeListAdminActivity.this, RecipeAddActivity.class);
                intent.putExtra("categoryId", categoryId);
                intent.putExtra("categoryTitle", categoryTitle);
                RecipeListAdminActivity.this.startActivity(intent);
            }
        });

    }

    private void loadRecipeList() {
        recipeArrayList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.orderByChild("categoryId").equalTo(categoryId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        recipeArrayList.clear();
                        for (DataSnapshot ds: snapshot.getChildren()) {
                            ModelRecipe model = ds.getValue(ModelRecipe.class);
                            recipeArrayList.add(model);


                        }

                        adapterRecipeAdmin = new AdapterRecipeAdmin(
                                RecipeListAdminActivity.this, recipeArrayList);
                        binding.recipeRv.setAdapter(adapterRecipeAdmin);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}