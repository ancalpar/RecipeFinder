package com.example.recipeFinder.activities.userActivities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.recipeFinder.adapters.AdapterRecipeUser;
import com.example.recipeFinder.databinding.FragmentRecipesUserBinding;
import com.example.recipeFinder.models.ModelRecipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RecipesUserFragment extends Fragment {

    private String categoryId;
    private String category;
    private String uid;


    private ArrayList<ModelRecipe> recipeArrayList;
    private AdapterRecipeUser adapterRecipeUser;

    private FragmentRecipesUserBinding binding;

    public RecipesUserFragment() {
        // Required empty public constructor
    }

    public static RecipesUserFragment newInstance(String categoryId, String category, String uid) {
        RecipesUserFragment fragment = new RecipesUserFragment();
        Bundle args = new Bundle();
        args.putString("categoryId", categoryId);
        args.putString("category", category);
        args.putString("uid", uid);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            categoryId = getArguments().getString("categoryId");
            category = getArguments().getString("category");
            uid = getArguments().getString("uid");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRecipesUserBinding.inflate(LayoutInflater.from(getContext()),
                container, false);

        if (category.equals("All")) {
            loadAllRecipes();
        } else if (category.equals("Most Viewed")) {
            loadMostViewedRecipes("viewsCount");
        }
        else {
            loadCategorizedRecipes();
        }

        binding.searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                try {
                    adapterRecipeUser.getFilter().filter(s);
                }
                catch (Exception e) {

                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        return binding.getRoot();
    }



    private void loadAllRecipes() {

        recipeArrayList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                recipeArrayList.clear();
                for (DataSnapshot ds: snapshot.getChildren()) {
                    ModelRecipe model = ds.getValue(ModelRecipe.class);
                    recipeArrayList.add(model);
                }

                adapterRecipeUser = new AdapterRecipeUser(getContext(), recipeArrayList);
                binding.recipesRv.setAdapter(adapterRecipeUser);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void loadMostViewedRecipes(String orderBy) {

        recipeArrayList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.orderByChild(orderBy).limitToLast(10)
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                recipeArrayList.clear();
                for (DataSnapshot ds: snapshot.getChildren()) {
                    ModelRecipe model = ds.getValue(ModelRecipe.class);
                    recipeArrayList.add(model);
                }

                adapterRecipeUser = new AdapterRecipeUser(getContext(), recipeArrayList);
                binding.recipesRv.setAdapter(adapterRecipeUser);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void loadCategorizedRecipes() {

        recipeArrayList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.orderByChild("categoryId").equalTo(categoryId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        recipeArrayList.clear();
                        for (DataSnapshot ds: snapshot.getChildren()) {
                            ModelRecipe model = ds.getValue(ModelRecipe.class);
                            recipeArrayList.add(model);
                        }

                        adapterRecipeUser = new AdapterRecipeUser(getContext(), recipeArrayList);
                        binding.recipesRv.setAdapter(adapterRecipeUser);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }
}