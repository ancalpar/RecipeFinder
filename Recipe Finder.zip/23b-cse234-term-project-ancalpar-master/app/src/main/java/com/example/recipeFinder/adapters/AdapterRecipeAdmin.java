package com.example.recipeFinder.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recipeFinder.MyApplication;
import com.example.recipeFinder.activities.RecipeDetailsActivity;
import com.example.recipeFinder.activities.adminActivities.RecipeEditActivity;
import com.example.recipeFinder.databinding.RowRecipeAdminBinding;
import com.example.recipeFinder.filters.FilterRecipeAdmin;
import com.example.recipeFinder.models.ModelRecipe;

import java.util.ArrayList;

public class AdapterRecipeAdmin extends RecyclerView.Adapter<AdapterRecipeAdmin.HolderRecipeAdmin>
implements Filterable {

    private Context context;
    public ArrayList<ModelRecipe> recipeArrayList, filterList;

    private RowRecipeAdminBinding binding;
    private FilterRecipeAdmin filter;

    private ProgressDialog progressDialog;

    public AdapterRecipeAdmin(Context context, ArrayList<ModelRecipe> recipeArrayList) {
        this.context = context;
        this.recipeArrayList = recipeArrayList;
        this.filterList = recipeArrayList;

        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Please wait");
        progressDialog.setCanceledOnTouchOutside(false);
    }

    @NonNull
    @Override
    public HolderRecipeAdmin onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = RowRecipeAdminBinding.inflate(LayoutInflater.from(context), parent, false);

        return new HolderRecipeAdmin(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull HolderRecipeAdmin holder, int position) {
        ModelRecipe model = recipeArrayList.get(position);


        String title = model.getTitle();
        String description = model.getDescription();
        String recipeId = model.getId();
        String categoryId = model.getCategoryId();


        holder.titleTv.setText(title);
        holder.descriptionTv.setText(description);

        MyApplication.loadCategory(
                "" + categoryId,
                holder.categoryTv
        );

        holder.moreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { moreOptionsDialog(model, holder);}
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RecipeDetailsActivity.class);
                intent.putExtra("recipeId", recipeId);
                context.startActivity(intent);
            }
        });
    }

    private void moreOptionsDialog(ModelRecipe model, HolderRecipeAdmin holder) {
        String recipeId = model.getId();
        String recipeTitle = model.getTitle();


        String[] options = {"Edit", "Delete"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle("Choose Options")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            Intent intent = new Intent(context, RecipeEditActivity.class);
                            intent.putExtra("recipeId", recipeId);
                            context.startActivity(intent);
                        }
                        else if (which == 1) {
                            MyApplication.deleteRecipe(
                                    context,
                                    "" + recipeId,
                                    "" + recipeTitle
                            );
                        }
                    }
                }).show();
    }

    @Override
    public int getItemCount() {
        return recipeArrayList.size();
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new FilterRecipeAdmin(filterList, this);
        }
        return filter;
    }

    class HolderRecipeAdmin extends RecyclerView.ViewHolder {
        TextView titleTv, descriptionTv, categoryTv;
        ImageButton moreButton;
        public HolderRecipeAdmin(@NonNull View itemView) {
            super(itemView);

            titleTv = binding.titleTv;
            descriptionTv = binding.descriptionTv;
            categoryTv = binding.categoryTv;
            moreButton = binding.moreButton;
        }
    }
}
