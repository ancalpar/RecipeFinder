package com.example.recipeFinder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recipeFinder.MyApplication;
import com.example.recipeFinder.activities.RecipeDetailsActivity;
import com.example.recipeFinder.databinding.RowFavoriteRecipesBinding;
import com.example.recipeFinder.models.ModelRecipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdapterRecipeFavorite extends RecyclerView.Adapter<AdapterRecipeFavorite.HolderRecipeFavorite> {

    private Context context;
    private ArrayList<ModelRecipe> recipeArrayList;

    private RowFavoriteRecipesBinding binding;

    public AdapterRecipeFavorite(Context context, ArrayList<ModelRecipe> recipeArrayList) {
        this.context = context;
        this.recipeArrayList = recipeArrayList;
    }

    @NonNull
    @Override
    public HolderRecipeFavorite onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        binding = RowFavoriteRecipesBinding.inflate(LayoutInflater.from(context), parent, false);

        return new HolderRecipeFavorite(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull HolderRecipeFavorite holder, int position) {

        ModelRecipe model = recipeArrayList.get(position);

        loadRecipeDetails(model, holder);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RecipeDetailsActivity.class);
                intent.putExtra("recipeId", model.getId());
                context.startActivity(intent);
            }
        });

        holder.removeFavoriteIb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApplication.removeFromFavorite(context, model.getId());
            }
        });
    }

    private void loadRecipeDetails(ModelRecipe model, HolderRecipeFavorite holder) {
        String recipeId = model.getId();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Recipes");
        ref.child(recipeId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String recipeTitle = "" + snapshot.child("title").getValue();
                        String description = "" + snapshot.child("description").getValue();
                        String categoryId = "" + snapshot.child("categoryId").getValue();
                        String uid = "" + snapshot.child("uid").getValue();

                        model.setFavorite(true);
                        model.setTitle(recipeTitle);
                        model.setDescription(description);
                        model.setCategoryId(categoryId);
                        model.setUid(uid);

                        MyApplication.loadCategory(categoryId, holder.categoryTv);

                        holder.titleTv.setText(recipeTitle);
                        holder.descriptionTv.setText(description);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }


    @Override
    public int getItemCount() {
        return recipeArrayList.size();
    }

    class HolderRecipeFavorite extends RecyclerView.ViewHolder {

        TextView titleTv, descriptionTv, categoryTv;
        ImageButton removeFavoriteIb;

        public HolderRecipeFavorite(@NonNull View itemView) {
            super(itemView);

            titleTv = binding.titleTv;
            removeFavoriteIb = binding.removeFavoriteIb;
            descriptionTv = binding.descriptionTv;
            categoryTv = binding.categoryTv;
        }
    }
}
