package com.example.recipeFinder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recipeFinder.MyApplication;
import com.example.recipeFinder.activities.RecipeDetailsActivity;
import com.example.recipeFinder.databinding.RowRecipeUserBinding;
import com.example.recipeFinder.filters.FilterRecipeUser;
import com.example.recipeFinder.models.ModelRecipe;

import java.util.ArrayList;

public class AdapterRecipeUser extends RecyclerView.Adapter<AdapterRecipeUser.HolderRecipeUser>
        implements Filterable {

    private Context context;
    public ArrayList<ModelRecipe> recipeArrayList, filterList;
    private FilterRecipeUser filter;

    private RowRecipeUserBinding binding;

    public AdapterRecipeUser(Context context, ArrayList<ModelRecipe> recipeArrayList) {
        this.context = context;
        this.recipeArrayList = recipeArrayList;
        this.filterList = recipeArrayList;
    }


    @Override
    public HolderRecipeUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        binding = RowRecipeUserBinding.inflate(LayoutInflater.from(context), parent, false);
        return new HolderRecipeUser(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull HolderRecipeUser holder, int position) {

        ModelRecipe model = recipeArrayList.get(position);
        String recipeId = model.getId();
        String title = model.getTitle();
        String description = model.getDescription();
        String categoryId = model.getCategoryId();


        holder.titleTv.setText(title);
        holder.descriptionTv.setText(description);

        MyApplication.loadCategory(
                "" + categoryId,
                holder.categoryTv
        );

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RecipeDetailsActivity.class);
                intent.putExtra("recipeId", recipeId);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return recipeArrayList.size();
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new FilterRecipeUser(filterList, this);
        }
        return filter;
    }

    class HolderRecipeUser extends RecyclerView.ViewHolder {

        TextView titleTv, descriptionTv, categoryTv;
        public HolderRecipeUser(@NonNull View itemView) {
            super(itemView);

            titleTv = binding.titleTv;
            descriptionTv = binding.descriptionTv;
            categoryTv = binding.categoryTv;
        }
    }
}
