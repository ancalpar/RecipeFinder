package com.example.recipeFinder.filters;

import android.widget.Filter;

import com.example.recipeFinder.adapters.AdapterCategory;
import com.example.recipeFinder.adapters.AdapterRecipeAdmin;
import com.example.recipeFinder.models.ModelCategory;
import com.example.recipeFinder.models.ModelRecipe;

import java.util.ArrayList;

public class FilterRecipeAdmin extends Filter {
    ArrayList<ModelRecipe> filterList;
    AdapterRecipeAdmin adapterRecipeAdmin;

    public FilterRecipeAdmin(ArrayList<ModelRecipe> filerList, AdapterRecipeAdmin adapterRecipeAdmin) {
        this.filterList = filerList;
        this.adapterRecipeAdmin = adapterRecipeAdmin;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();
        if (constraint != null && constraint.length() > 0) {

            constraint = constraint.toString().toUpperCase();
            ArrayList<ModelRecipe> filteredModels = new ArrayList<>();

            for (int i = 0; i < filterList.size(); i++) {
                if (filterList.get(i).getTitle().toUpperCase().contains(constraint)) {
                    filteredModels.add(filterList.get(i));
                }
            }

            results.count = filteredModels.size();
            results.values = filteredModels;
        }
        else {
            results.count = filterList.size();
            results.values = filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapterRecipeAdmin.recipeArrayList = (ArrayList<ModelRecipe>) results.values;

        adapterRecipeAdmin.notifyDataSetChanged();
    }
}
