package com.example.recipeFinder.filters;

import android.widget.Filter;

import com.example.recipeFinder.adapters.AdapterRecipeUser;
import com.example.recipeFinder.models.ModelRecipe;

import java.util.ArrayList;

public class FilterRecipeUser extends Filter {

    ArrayList<ModelRecipe> filterList;
    AdapterRecipeUser adapterRecipeUser;


    public FilterRecipeUser(ArrayList<ModelRecipe> filterList, AdapterRecipeUser adapterRecipeUser) {
        this.filterList = filterList;
        this.adapterRecipeUser = adapterRecipeUser;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        if (constraint != null || constraint.length() > 0) {
            constraint = constraint.toString().toUpperCase();
            ArrayList<ModelRecipe> filteredModels = new ArrayList<>();

            for (int i = 0; i < filterList.size(); i++) {
                if (filterList.get(i).getTitle().toUpperCase().contains(constraint)) {
                    filteredModels.add(filterList.get(i));
                }
            }

            results.count = filteredModels.size();
            results.values = filteredModels;
        }
        else {
            results.count = filterList.size();
            results.values = filterList;
        }

        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {

        adapterRecipeUser.recipeArrayList = (ArrayList<ModelRecipe>)results.values;

        adapterRecipeUser.notifyDataSetChanged();
    }
}
